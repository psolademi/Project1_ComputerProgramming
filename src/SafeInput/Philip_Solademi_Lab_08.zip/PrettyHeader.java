package Resource;

public class PrettyHeader {
    public static void main(String[] args) {
        SafeInput.prettyHeader("Enter Your Message");
    }
}