public class GettingLoopy {
    public static void main(String args[])
    {
        // Count up to 30
        for (int i = 0; i <= 30; i++)
        {
            System.out.println(i);
        }
    }
}
