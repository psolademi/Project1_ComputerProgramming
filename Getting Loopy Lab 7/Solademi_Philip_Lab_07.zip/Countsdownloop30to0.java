public class Countsdownloop30to0 {
    public static void main(String args[])
    {
        // Countdown from 30-0
        for (int i = 30; i >= 0; i--)
        {
            // Print result
            System.out.println(i);
        }
    }
}
