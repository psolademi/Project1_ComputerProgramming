public class Countdownby2 {
    public static void main(String args[])
    {
        // For countdown of 10 - 2
        for (int i = 10; i >= 0; i -= 2)
        {
            // Print result
            System.out.println(i);
        }
    }
}
