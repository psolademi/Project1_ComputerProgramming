public class countupby3 {
    public static void main(String args[])
    {
        // Count up by 3 to 18
        for (int i = 0; i <= 18; i += 3)
        {
            // Print result
            System.out.println(i);
        }
    }
}
